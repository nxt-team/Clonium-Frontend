self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "88539d4a9ba0d52ea2e9bd8cdb77fe71",
    "url": "/index.html"
  },
  {
    "revision": "0e38f411d7541e266897",
    "url": "/static/css/2.cdee455b.chunk.css"
  },
  {
    "revision": "e92e5ef5ae25ae810e8d",
    "url": "/static/css/main.3a12c769.chunk.css"
  },
  {
    "revision": "0e38f411d7541e266897",
    "url": "/static/js/2.0daa7df8.chunk.js"
  },
  {
    "revision": "8924c7a8dfcbb0c0ea31992e48f450cb",
    "url": "/static/js/2.0daa7df8.chunk.js.LICENSE.txt"
  },
  {
    "revision": "e92e5ef5ae25ae810e8d",
    "url": "/static/js/main.f9663fe8.chunk.js"
  },
  {
    "revision": "b1309482619b70e387b5",
    "url": "/static/js/runtime-main.319faef6.js"
  },
  {
    "revision": "0014358aa07ad7444b94d9f962d6b968",
    "url": "/static/media/fallback_question_orange.0014358a.png"
  },
  {
    "revision": "2ef3cb58cb9e028e1901352f478d4c7b",
    "url": "/static/media/fluid 10.2ef3cb58.png"
  },
  {
    "revision": "0ba2fa01494a138b35d0b15b50d722f9",
    "url": "/static/media/waving-hand.0ba2fa01.png"
  }
]);