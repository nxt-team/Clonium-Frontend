self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "97ea861f29eabc041039f1ba201775d0",
    "url": "./index.html"
  },
  {
    "revision": "cb6f64a9360757642826",
    "url": "./static/css/2.cdee455b.chunk.css"
  },
  {
    "revision": "93f25765c0a145ea9174",
    "url": "./static/css/main.a02f3b04.chunk.css"
  },
  {
    "revision": "cb6f64a9360757642826",
    "url": "./static/js/2.523f9bbb.chunk.js"
  },
  {
    "revision": "d4d26d6ca87baff440b7dc2e4d46ba7f",
    "url": "./static/js/2.523f9bbb.chunk.js.LICENSE.txt"
  },
  {
    "revision": "93f25765c0a145ea9174",
    "url": "./static/js/main.c9c2b3ee.chunk.js"
  },
  {
    "revision": "2564d51f3f7cc87584f5",
    "url": "./static/js/runtime-main.de98bd88.js"
  },
  {
    "revision": "2ef3cb58cb9e028e1901352f478d4c7b",
    "url": "./static/media/fluid 10.2ef3cb58.png"
  },
  {
    "revision": "0ba2fa01494a138b35d0b15b50d722f9",
    "url": "./static/media/waving-hand.0ba2fa01.png"
  }
]);