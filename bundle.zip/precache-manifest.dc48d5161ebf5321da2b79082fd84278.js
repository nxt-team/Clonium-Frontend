self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "e0b1439da9fa5da39dd52d4f30c3b4d3",
    "url": "./index.html"
  },
  {
    "revision": "45d858e15454d385a2d1",
    "url": "./static/css/2.cdee455b.chunk.css"
  },
  {
    "revision": "0b30d7484956af536a98",
    "url": "./static/css/main.c83f0e0a.chunk.css"
  },
  {
    "revision": "45d858e15454d385a2d1",
    "url": "./static/js/2.e56ae81a.chunk.js"
  },
  {
    "revision": "d4d26d6ca87baff440b7dc2e4d46ba7f",
    "url": "./static/js/2.e56ae81a.chunk.js.LICENSE.txt"
  },
  {
    "revision": "c665e3139fe5b5dd4195",
    "url": "./static/js/3.dad9b34d.chunk.js"
  },
  {
    "revision": "d7443f9307dcf29caba326ef49b2f7f6",
    "url": "./static/js/3.dad9b34d.chunk.js.LICENSE.txt"
  },
  {
    "revision": "3b4492b78cb9aa9daacd",
    "url": "./static/js/4.8e12690a.chunk.js"
  },
  {
    "revision": "0b30d7484956af536a98",
    "url": "./static/js/main.865fe7df.chunk.js"
  },
  {
    "revision": "867ff4ffa67bbf60b429",
    "url": "./static/js/runtime-main.4584f0c7.js"
  },
  {
    "revision": "2ef3cb58cb9e028e1901352f478d4c7b",
    "url": "./static/media/fluid 10.2ef3cb58.png"
  },
  {
    "revision": "0ba2fa01494a138b35d0b15b50d722f9",
    "url": "./static/media/waving-hand.0ba2fa01.png"
  }
]);