self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "d6298619557a9b83221c35f60d214249",
    "url": "/index.html"
  },
  {
    "revision": "ec2c52b5a129f330f215",
    "url": "/static/css/2.cdee455b.chunk.css"
  },
  {
    "revision": "97ce5c67f2ed2dcc86d6",
    "url": "/static/css/main.3a12c769.chunk.css"
  },
  {
    "revision": "ec2c52b5a129f330f215",
    "url": "/static/js/2.fb21406f.chunk.js"
  },
  {
    "revision": "8924c7a8dfcbb0c0ea31992e48f450cb",
    "url": "/static/js/2.fb21406f.chunk.js.LICENSE.txt"
  },
  {
    "revision": "97ce5c67f2ed2dcc86d6",
    "url": "/static/js/main.1bc8e8e5.chunk.js"
  },
  {
    "revision": "b1309482619b70e387b5",
    "url": "/static/js/runtime-main.319faef6.js"
  },
  {
    "revision": "0014358aa07ad7444b94d9f962d6b968",
    "url": "/static/media/fallback_question_orange.0014358a.png"
  },
  {
    "revision": "2ef3cb58cb9e028e1901352f478d4c7b",
    "url": "/static/media/fluid 10.2ef3cb58.png"
  },
  {
    "revision": "0ba2fa01494a138b35d0b15b50d722f9",
    "url": "/static/media/waving-hand.0ba2fa01.png"
  }
]);