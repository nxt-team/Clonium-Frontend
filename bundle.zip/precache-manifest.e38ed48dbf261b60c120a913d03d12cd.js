self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "82eed5925d7c5a94552ae896a319544a",
    "url": "/index.html"
  },
  {
    "revision": "3bea09195f15679237c2",
    "url": "/static/css/2.cdee455b.chunk.css"
  },
  {
    "revision": "05429ae39d5caa804288",
    "url": "/static/css/main.436c4d3c.chunk.css"
  },
  {
    "revision": "3bea09195f15679237c2",
    "url": "/static/js/2.260edad6.chunk.js"
  },
  {
    "revision": "8924c7a8dfcbb0c0ea31992e48f450cb",
    "url": "/static/js/2.260edad6.chunk.js.LICENSE.txt"
  },
  {
    "revision": "05429ae39d5caa804288",
    "url": "/static/js/main.9e177f76.chunk.js"
  },
  {
    "revision": "b1309482619b70e387b5",
    "url": "/static/js/runtime-main.319faef6.js"
  }
]);