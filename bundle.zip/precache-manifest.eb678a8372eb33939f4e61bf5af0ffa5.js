self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "528779181569057c207c3f1cd0a9d21a",
    "url": "/index.html"
  },
  {
    "revision": "6de0ea66cebea5f5fe47",
    "url": "/static/css/2.cdee455b.chunk.css"
  },
  {
    "revision": "3cc3ad3f723c7c04430c",
    "url": "/static/css/main.3f0ac195.chunk.css"
  },
  {
    "revision": "6de0ea66cebea5f5fe47",
    "url": "/static/js/2.aebe33a8.chunk.js"
  },
  {
    "revision": "d4d26d6ca87baff440b7dc2e4d46ba7f",
    "url": "/static/js/2.aebe33a8.chunk.js.LICENSE.txt"
  },
  {
    "revision": "3cc3ad3f723c7c04430c",
    "url": "/static/js/main.e589edfc.chunk.js"
  },
  {
    "revision": "b1309482619b70e387b5",
    "url": "/static/js/runtime-main.319faef6.js"
  },
  {
    "revision": "0014358aa07ad7444b94d9f962d6b968",
    "url": "/static/media/fallback_question_orange.0014358a.png"
  },
  {
    "revision": "2ef3cb58cb9e028e1901352f478d4c7b",
    "url": "/static/media/fluid 10.2ef3cb58.png"
  },
  {
    "revision": "0ba2fa01494a138b35d0b15b50d722f9",
    "url": "/static/media/waving-hand.0ba2fa01.png"
  }
]);