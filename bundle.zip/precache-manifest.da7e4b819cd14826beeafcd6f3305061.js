self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "d07445d2289aa157401b5e528086503d",
    "url": "/index.html"
  },
  {
    "revision": "2b3f8f784314f60fe3c6",
    "url": "/static/css/2.cdee455b.chunk.css"
  },
  {
    "revision": "f8f3648a198386df4fab",
    "url": "/static/css/main.56545d83.chunk.css"
  },
  {
    "revision": "2b3f8f784314f60fe3c6",
    "url": "/static/js/2.1336e1b0.chunk.js"
  },
  {
    "revision": "d4d26d6ca87baff440b7dc2e4d46ba7f",
    "url": "/static/js/2.1336e1b0.chunk.js.LICENSE.txt"
  },
  {
    "revision": "f8f3648a198386df4fab",
    "url": "/static/js/main.9307cefd.chunk.js"
  },
  {
    "revision": "b1309482619b70e387b5",
    "url": "/static/js/runtime-main.319faef6.js"
  },
  {
    "revision": "0014358aa07ad7444b94d9f962d6b968",
    "url": "/static/media/fallback_question_orange.0014358a.png"
  },
  {
    "revision": "2ef3cb58cb9e028e1901352f478d4c7b",
    "url": "/static/media/fluid 10.2ef3cb58.png"
  },
  {
    "revision": "0ba2fa01494a138b35d0b15b50d722f9",
    "url": "/static/media/waving-hand.0ba2fa01.png"
  }
]);