self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "8972cd515698815f94a429574c668b75",
    "url": "./index.html"
  },
  {
    "revision": "45d858e15454d385a2d1",
    "url": "./static/css/2.cdee455b.chunk.css"
  },
  {
    "revision": "9553ac1df3a528d19da0",
    "url": "./static/css/main.c83f0e0a.chunk.css"
  },
  {
    "revision": "45d858e15454d385a2d1",
    "url": "./static/js/2.e56ae81a.chunk.js"
  },
  {
    "revision": "d4d26d6ca87baff440b7dc2e4d46ba7f",
    "url": "./static/js/2.e56ae81a.chunk.js.LICENSE.txt"
  },
  {
    "revision": "c665e3139fe5b5dd4195",
    "url": "./static/js/3.dad9b34d.chunk.js"
  },
  {
    "revision": "d7443f9307dcf29caba326ef49b2f7f6",
    "url": "./static/js/3.dad9b34d.chunk.js.LICENSE.txt"
  },
  {
    "revision": "3b4492b78cb9aa9daacd",
    "url": "./static/js/4.8e12690a.chunk.js"
  },
  {
    "revision": "9553ac1df3a528d19da0",
    "url": "./static/js/main.8faa8087.chunk.js"
  },
  {
    "revision": "867ff4ffa67bbf60b429",
    "url": "./static/js/runtime-main.4584f0c7.js"
  },
  {
    "revision": "2ef3cb58cb9e028e1901352f478d4c7b",
    "url": "./static/media/fluid 10.2ef3cb58.png"
  },
  {
    "revision": "0ba2fa01494a138b35d0b15b50d722f9",
    "url": "./static/media/waving-hand.0ba2fa01.png"
  }
]);