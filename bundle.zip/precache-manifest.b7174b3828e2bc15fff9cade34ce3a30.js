self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "7d47ae8c2c4733b56d862b7c2a5a3731",
    "url": "/index.html"
  },
  {
    "revision": "ca5bc6190664533f6103",
    "url": "/static/css/2.cdee455b.chunk.css"
  },
  {
    "revision": "2c565638594039ad2087",
    "url": "/static/css/main.e0ddd308.chunk.css"
  },
  {
    "revision": "ca5bc6190664533f6103",
    "url": "/static/js/2.2ab55b5a.chunk.js"
  },
  {
    "revision": "d4d26d6ca87baff440b7dc2e4d46ba7f",
    "url": "/static/js/2.2ab55b5a.chunk.js.LICENSE.txt"
  },
  {
    "revision": "2c565638594039ad2087",
    "url": "/static/js/main.52af92ea.chunk.js"
  },
  {
    "revision": "b1309482619b70e387b5",
    "url": "/static/js/runtime-main.319faef6.js"
  },
  {
    "revision": "0014358aa07ad7444b94d9f962d6b968",
    "url": "/static/media/fallback_question_orange.0014358a.png"
  },
  {
    "revision": "2ef3cb58cb9e028e1901352f478d4c7b",
    "url": "/static/media/fluid 10.2ef3cb58.png"
  },
  {
    "revision": "0ba2fa01494a138b35d0b15b50d722f9",
    "url": "/static/media/waving-hand.0ba2fa01.png"
  }
]);