self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "87e8b14a3c3680a4e05c76752ab9b84a",
    "url": "/index.html"
  },
  {
    "revision": "32596fd59c3c08ae2f9b",
    "url": "/static/css/2.cdee455b.chunk.css"
  },
  {
    "revision": "94c90e7b750c5ef17a87",
    "url": "/static/css/main.2ddb809d.chunk.css"
  },
  {
    "revision": "32596fd59c3c08ae2f9b",
    "url": "/static/js/2.fa180be7.chunk.js"
  },
  {
    "revision": "8924c7a8dfcbb0c0ea31992e48f450cb",
    "url": "/static/js/2.fa180be7.chunk.js.LICENSE.txt"
  },
  {
    "revision": "94c90e7b750c5ef17a87",
    "url": "/static/js/main.3c01262f.chunk.js"
  },
  {
    "revision": "b1309482619b70e387b5",
    "url": "/static/js/runtime-main.319faef6.js"
  },
  {
    "revision": "2ef3cb58cb9e028e1901352f478d4c7b",
    "url": "/static/media/fluid 10.2ef3cb58.png"
  },
  {
    "revision": "0ba2fa01494a138b35d0b15b50d722f9",
    "url": "/static/media/waving-hand.0ba2fa01.png"
  }
]);