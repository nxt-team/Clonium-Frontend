self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "5908c644188f6f6f0bf0edccd27c5cce",
    "url": "/index.html"
  },
  {
    "revision": "59e21f9b4b565ec0b0aa",
    "url": "/static/css/2.cdee455b.chunk.css"
  },
  {
    "revision": "cd0091a99089b727eaf7",
    "url": "/static/css/main.bb8fcb58.chunk.css"
  },
  {
    "revision": "59e21f9b4b565ec0b0aa",
    "url": "/static/js/2.1525bd0e.chunk.js"
  },
  {
    "revision": "8924c7a8dfcbb0c0ea31992e48f450cb",
    "url": "/static/js/2.1525bd0e.chunk.js.LICENSE.txt"
  },
  {
    "revision": "cd0091a99089b727eaf7",
    "url": "/static/js/main.29f8ed81.chunk.js"
  },
  {
    "revision": "b1309482619b70e387b5",
    "url": "/static/js/runtime-main.319faef6.js"
  }
]);