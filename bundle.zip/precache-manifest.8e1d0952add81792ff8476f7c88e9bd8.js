self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "24dc67f1084fa395bd8ef7ad016119de",
    "url": "./index.html"
  },
  {
    "revision": "4884cf005257df6a8194",
    "url": "./static/css/2.cdee455b.chunk.css"
  },
  {
    "revision": "9bdd049b3135bbec8a9b",
    "url": "./static/css/main.b0de60b5.chunk.css"
  },
  {
    "revision": "4884cf005257df6a8194",
    "url": "./static/js/2.244d0e00.chunk.js"
  },
  {
    "revision": "d4d26d6ca87baff440b7dc2e4d46ba7f",
    "url": "./static/js/2.244d0e00.chunk.js.LICENSE.txt"
  },
  {
    "revision": "c8fb2228890068423a1a",
    "url": "./static/js/3.e761da56.chunk.js"
  },
  {
    "revision": "d7443f9307dcf29caba326ef49b2f7f6",
    "url": "./static/js/3.e761da56.chunk.js.LICENSE.txt"
  },
  {
    "revision": "01a1db409deb2103c77a",
    "url": "./static/js/4.9d530792.chunk.js"
  },
  {
    "revision": "9bdd049b3135bbec8a9b",
    "url": "./static/js/main.7d514736.chunk.js"
  },
  {
    "revision": "4ce86b7f0bb95fdd3b4d",
    "url": "./static/js/runtime-main.dc205dff.js"
  },
  {
    "revision": "2ef3cb58cb9e028e1901352f478d4c7b",
    "url": "./static/media/fluid 10.2ef3cb58.png"
  },
  {
    "revision": "0ba2fa01494a138b35d0b15b50d722f9",
    "url": "./static/media/waving-hand.0ba2fa01.png"
  }
]);