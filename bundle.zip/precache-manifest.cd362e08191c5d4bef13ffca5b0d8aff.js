self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "315c64d36e6931b8f857f1e3609387be",
    "url": "/index.html"
  },
  {
    "revision": "3d9b10b4b4757451b8b8",
    "url": "/static/css/2.cdee455b.chunk.css"
  },
  {
    "revision": "adb448dfeae19c49a9c8",
    "url": "/static/css/main.2ac410b9.chunk.css"
  },
  {
    "revision": "3d9b10b4b4757451b8b8",
    "url": "/static/js/2.4b185a42.chunk.js"
  },
  {
    "revision": "8924c7a8dfcbb0c0ea31992e48f450cb",
    "url": "/static/js/2.4b185a42.chunk.js.LICENSE.txt"
  },
  {
    "revision": "adb448dfeae19c49a9c8",
    "url": "/static/js/main.4edb4379.chunk.js"
  },
  {
    "revision": "b1309482619b70e387b5",
    "url": "/static/js/runtime-main.319faef6.js"
  },
  {
    "revision": "2ef3cb58cb9e028e1901352f478d4c7b",
    "url": "/static/media/fluid 10.2ef3cb58.png"
  },
  {
    "revision": "0ba2fa01494a138b35d0b15b50d722f9",
    "url": "/static/media/waving-hand.0ba2fa01.png"
  }
]);