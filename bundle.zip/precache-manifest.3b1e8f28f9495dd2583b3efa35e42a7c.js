self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "1ce9b59f9e2a93c2a8d290808f4dba8f",
    "url": "./index.html"
  },
  {
    "revision": "7ef99498a90e92d69dd5",
    "url": "./static/css/2.cdee455b.chunk.css"
  },
  {
    "revision": "0637c86077284dfd0c89",
    "url": "./static/css/main.db6facf2.chunk.css"
  },
  {
    "revision": "7ef99498a90e92d69dd5",
    "url": "./static/js/2.58c13a2c.chunk.js"
  },
  {
    "revision": "d4d26d6ca87baff440b7dc2e4d46ba7f",
    "url": "./static/js/2.58c13a2c.chunk.js.LICENSE.txt"
  },
  {
    "revision": "0dbbcce185700f3709b7",
    "url": "./static/js/3.6cd9bdc7.chunk.js"
  },
  {
    "revision": "d7443f9307dcf29caba326ef49b2f7f6",
    "url": "./static/js/3.6cd9bdc7.chunk.js.LICENSE.txt"
  },
  {
    "revision": "62036418519b11d2c0b0",
    "url": "./static/js/4.60b0e31f.chunk.js"
  },
  {
    "revision": "0637c86077284dfd0c89",
    "url": "./static/js/main.2f8b1eba.chunk.js"
  },
  {
    "revision": "4094ddf22917020b969d",
    "url": "./static/js/runtime-main.e16344fa.js"
  },
  {
    "revision": "2ef3cb58cb9e028e1901352f478d4c7b",
    "url": "./static/media/fluid 10.2ef3cb58.png"
  },
  {
    "revision": "0ba2fa01494a138b35d0b15b50d722f9",
    "url": "./static/media/waving-hand.0ba2fa01.png"
  }
]);