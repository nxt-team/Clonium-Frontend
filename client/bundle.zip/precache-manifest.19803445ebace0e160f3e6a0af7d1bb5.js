self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "add9f7f17bd4a9f85efe07b327accb20",
    "url": "/index.html"
  },
  {
    "revision": "45d66e22a763a444a1f7",
    "url": "/static/css/2.86df01db.chunk.css"
  },
  {
    "revision": "5cdadd821c3fc8fb78c2",
    "url": "/static/css/main.34030b7f.chunk.css"
  },
  {
    "revision": "45d66e22a763a444a1f7",
    "url": "/static/js/2.6f67f72b.chunk.js"
  },
  {
    "revision": "c3e0fd4dfd1cc3858a8f07ed5cf951b5",
    "url": "/static/js/2.6f67f72b.chunk.js.LICENSE.txt"
  },
  {
    "revision": "5cdadd821c3fc8fb78c2",
    "url": "/static/js/main.00c8290e.chunk.js"
  },
  {
    "revision": "b1309482619b70e387b5",
    "url": "/static/js/runtime-main.319faef6.js"
  },
  {
    "revision": "a587eb35183a51a55f15f75f1cc6cbf2",
    "url": "/static/media/download.a587eb35.png"
  },
  {
    "revision": "4e1ec8403d903dc514271d7328fbdeb3",
    "url": "/static/media/persik.4e1ec840.png"
  }
]);